The examples are mainly available for anyone to check if the FireDaemon OpenSSL binary distribution works as expected,
and for anyone who wants to understand how OpenSSL can be integrated into a project.

If you are looking for help integrating OpenSSL into your project, please contact FireDaemon for professional consulting and services.
