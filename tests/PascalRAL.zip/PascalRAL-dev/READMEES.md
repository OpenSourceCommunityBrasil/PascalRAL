![Banner](https://github.com/OpenSourceCommunityBrasil/PascalRAL/assets/26689802/170aeb26-ec75-42b7-a425-0363c2b3bb6f)
<br/><a href="https://discord.gg/pS2xjruCJH"><img alt="join Discord" src="https://img.shields.io/discord/918891794597544056?color=blue&label=OSCBr&logo=discord&style=social"></a>

<a href=".\READMEPT.md"><img src="https://img.shields.io/badge/Traduzir-PT--BR-blue" /></a><a href=".\READMEES.md"><img src="https://img.shields.io/badge/Traducir-ES--ES-blue" /></a><a href=".\README.md"><img src="https://img.shields.io/badge/Translate-EN--US-blue" /></a>

Pascal REST API Lite es un conjunto de componentes para crear y consumir servidores API RESTFul de una manera simple, liviana y rápida.

* [Lista de compatibilidad IDE]()
* [Guía de instalación]()
* [Ejemplos de uso](https://github.com/OpenSourceCommunityBrasil/PascalRAL-Demos)